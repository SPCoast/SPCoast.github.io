## cpNode-IOX-Plugin-Footprint

Expansion daughterboard "footprint" for cpNode-IOX

